package ejercicio1;

import java.util.Scanner;

public class ejercicio_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


     Scanner sc = new Scanner(System.in);
     int num;

     System.out.println("Introduzca un número entero:");
		        num = sc.nextInt();

		        if (num % 2 == 0) {
		            System.out.println("El número " + num + " es par");
		        } else {
		            System.out.println("El número " + num + " es impar");
		        }
	}

}
