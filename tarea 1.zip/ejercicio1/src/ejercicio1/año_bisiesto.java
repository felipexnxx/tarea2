package ejercicio1;

import java.util.Scanner;


public class año_bisiesto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Scanner sc = new Scanner(System.in);
	        int year;

	        System.out.println("Introduzca un año:");
	        year = sc.nextInt();

	        if ((year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0))) {
	            System.out.println("El año " + year + " es bisiesto");
	        } else {
	            System.out.println("El año " + year + " no es bisiesto");
	        }
	    }
}
